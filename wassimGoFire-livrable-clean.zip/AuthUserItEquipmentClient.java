package com.cnstn.intervention.client.itequipment;

import com.cnstn.intervention.client.permission.AuthUserPermissionClientProperties;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

@Component
public class AuthUserItEquipmentClient {

    private final RestTemplate authUserRestTemplate;
    private final AuthUserPermissionClientProperties properties;

    public AuthUserItEquipmentClient(
        @Qualifier("authUserPermissionRestTemplate") RestTemplate authUserRestTemplate,
        AuthUserPermissionClientProperties properties
    ) {
        this.authUserRestTemplate = authUserRestTemplate;
        this.properties = properties;
    }

    public InternalItEquipmentOwnershipResponse checkOwnership(UUID equipmentId, String employeeId) {
        HttpHeaders headers = internalHeaders();
        String path = UriComponentsBuilder.fromPath("/api/v1/internal/it-equipment/{equipmentId}/ownership")
            .queryParam("employeeId", employeeId)
            .buildAndExpand(equipmentId)
            .toUriString();

        try {
            return authUserRestTemplate.exchange(
                path,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                InternalItEquipmentOwnershipResponse.class
            ).getBody();
        } catch (RestClientResponseException ex) {
            throw new AuthUserItEquipmentClientException(
                "Equipment ownership check failed: status=" + ex.getStatusCode().value() + ", body=" + ex.getResponseBodyAsString(),
                ex.getStatusCode().value(),
                ex.getResponseBodyAsString(),
                ex
            );
        } catch (RestClientException ex) {
            throw new AuthUserItEquipmentClientException("Equipment ownership check failed", ex);
        }
    }

    public InternalItEquipmentSummaryResponse getSummary(UUID equipmentId) {
        HttpHeaders headers = internalHeaders();
        String path = "/api/v1/internal/it-equipment/" + equipmentId;

        try {
            return authUserRestTemplate.exchange(
                path,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                InternalItEquipmentSummaryResponse.class
            ).getBody();
        } catch (RestClientResponseException ex) {
            throw new AuthUserItEquipmentClientException(
                "Equipment summary fetch failed: status=" + ex.getStatusCode().value() + ", body=" + ex.getResponseBodyAsString(),
                ex.getStatusCode().value(),
                ex.getResponseBodyAsString(),
                ex
            );
        } catch (RestClientException ex) {
            throw new AuthUserItEquipmentClientException("Equipment summary fetch failed", ex);
        }
    }

    public InternalItEquipmentSummaryResponse updateState(UUID equipmentId, String state) {
        HttpHeaders headers = internalHeaders();
        String path = "/api/v1/internal/it-equipment/" + equipmentId + "/state";
        InternalItEquipmentStateUpdateRequest request = new InternalItEquipmentStateUpdateRequest(state);

        try {
            return authUserRestTemplate.exchange(
                path,
                HttpMethod.PATCH,
                new HttpEntity<>(request, headers),
                InternalItEquipmentSummaryResponse.class
            ).getBody();
        } catch (RestClientResponseException ex) {
            throw new AuthUserItEquipmentClientException(
                "Equipment state update failed: status=" + ex.getStatusCode().value() + ", body=" + ex.getResponseBodyAsString(),
                ex.getStatusCode().value(),
                ex.getResponseBodyAsString(),
                ex
            );
        } catch (RestClientException ex) {
            throw new AuthUserItEquipmentClientException("Equipment state update failed", ex);
        }
    }

    private HttpHeaders internalHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-Api-Key", properties.getInternalApiKey());
        return headers;
    }
}
